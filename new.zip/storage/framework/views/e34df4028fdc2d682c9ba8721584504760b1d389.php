<?php $__env->startComponent('mail::message'); ?>
# New Message From Cyber Falcon

<h1>Name: <?php echo e($data['name']); ?></h1>
<h1>Email Address: <?php echo e($data['email']); ?></h1>
<h1>Phone: <?php echo e($data['phone']); ?></h1>
<h1>Subject: <?php echo e($data['subject']); ?></h1>
<h1>Message: <?php echo e($data['message']); ?></h1>





<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH F:\laragon\www\cyber-falcon\resources\views/emails/contactMail.blade.php ENDPATH**/ ?>